$(document).ready(function(){
		$("dl.list dt").toggle(
			function(){$(this).next("dd").css("display","block");$(this).css("background-image","url('img/gallery/bg_dt_over.gif')");},
			function(){$(this).next("dd").css("display","none");$(this).css("background-image","url('img/gallery/bg_dt.gif')");}
		);
		
		$("#header ul.topNavi>li").eq(3).mouseover(function(){$(this).children("ul").show();});
		$("#header ul.topNavi>li").eq(3).mouseout(function(){$(this).children("ul").hide();});
});

function setValue(id,time){
				var images = new Array();
				var alts = new Array();
				var folder = "img/gallery/"+time+"/";
				switch(id){
					case 0:
						images = Array("IMG_0201.JPG","IMG_0204.JPG","IMG_0205.JPG","IMG_0207.JPG","IMG_0210.JPG","IMG_0212.JPG","IMG_0215.JPG","IMG_0220.JPG","IMG_0222.JPG","IMG_0225.JPG","IMG_0227.JPG");	
						alts = Array("","","","","","","","","","","");
						break;
						
					case 1:
						images = Array("IMG_0219.JPG","IMG_0236.JPG","IMG_0217.JPG","IMG_0224.JPG","IMG_0220.JPG","IMG_0213.JPG","IMG_0223.JPG","IMG_0242.JPG","IMG_0226.JPG","IMG_0232.JPG","IMG_0239.JPG");
						alts = Array("ハイデルベルク（Ⅰ）30.0 × 36.0","ライン川にて 32.0 × 26.5","ローテンブルグ（Ⅰ）26.5 × 32.0","ローテンブルグ（Ⅱ）26.5 × 32.0","ローテンブルグ（Ⅲ）27.0 × 34.0","ハイデルベルク（Ⅱ）25.5 × 32.0","ローテンブルグ（Ⅳ）42.0 × 51.0","ローテンブルグ（Ⅴ）22.5 × 28.0","ライン川沿いの教会 30.0 × 36.0","ハイデルベルク（Ⅲ）27.0 × 33.0","ハイデルベルク（Ⅳ）33.0 × 27.0");
						break;
						
					case 2:
						images = Array("IMG_0002.JPG","IMG_0205.JPG","1_hazirai.jpg","IMG_02031.JPG","7_sabisikara.jpg","5_takesima.jpg","IMG_0209.JPG","IMG_0210.JPG");
						alts = Array("ハイデルベルク（Ⅰ）30.0 × 36.0","ライン川にて 32.0 × 26.5","ローテンブルグ（Ⅰ）26.5 × 32.0","ローテンブルグ（Ⅱ）26.5 × 32.0","ローテンブルグ（Ⅲ）27.0 × 34.0","ハイデルベルク（Ⅱ）25.5 × 32.0","ローテンブルグ（Ⅳ）42.0 × 51.0","ローテンブルグ（Ⅴ）22.5 × 28.0");
						break;
						
					case 3:
						images = Array("IMG_0208.JPG","IMG_0221.JPG","IMG_0215.JPG","IMG_0224.jpg","IMG_0218.jpg","IMG_0214.JPG","IMG_0209.JPG");	
						alts = Array("高遠（Ｆ８）","ノイシュバンシュタイン城 （ドイツ）－マリエン橋よりー（Ｆ８）","ローテンブルグ（ドイツ）（Ｆ６）","アネモネ（Ⅰ）（Ｆ６）","アネモネ（Ⅱ）（Ｆ６）","花（Ｆ４）","アンモナイト（Ｆ３）");
						break;
						
					case 4:
						images = Array("4_anemone.jpg","3_indo.jpg","2_senyorita.jpg","1_hazirai.jpg","5_takesima.jpg","7_sabisikara.jpg","omake_1.jpg","shijou.JPG","katarai.JPG","IMG_0017.jpg");
						alts = Array("洋画　平野雪夫「アネモネ」58.5ｘ49.0","洋画　平野雪夫「アネモネ」58.5ｘ49.0水彩画　山田常利「インド」50.5ｘ65.0","パステル画　宿澤　浩「セニョリータ」62.0ｘ47.0","伝統創作版画　瀧　秀水「恥じらい」50.8ｘ38.0","水墨画　柳瀬辰久「竹島」28.0ｘ56.5","陶板　平子　純「寂しいから」33.5ｘ28.0","イラスト画　茶畑和也「オマケ」31.0ｘ26.0","水彩画　山田常利「市場にて」21.5ｘ27.5","水彩画　山田常利「語らい」25.5ｘ30.5","油彩 加藤信雄「ふたり」28､5×35､5");
						break;
					
					case 5:
						images = Array("IMG_0002.JPG","IMG_0006_thumb.jpg","IMG_0010.JPG","IMG_0015.JPG","IMG_0017_thumb.jpg","IMG_0020_thumb.jpg","IMG_0027.JPG");
						alts = Array("舞妓Ⅰ 38.5×54.0","舞妓Ⅱ　43.0×34.0","椿　36.5×44.0","Ｈappy Birthday 46.0×58.0","百合　44.5×37.0","舞妓Ⅲ　49.0×40.0","カトレア　46.0×58.0");
						break;
						
					case 6:
						images = Array("IMG_0036.jpg","IMG_0004.jpg","IMG_0003.jpg","IMG_0017.jpg","IMG_0006.JPG","IMG_0014.JPG","IMG_0032.JPG","IMG_0028.JPG","IMG_0012.jpg","IMG_0008.JPG","IMG_0031.JPG","IMG_0025.jpg","IMG_0023.jpg");
						alts = Array("愛知万博 2005 油彩 74､0 cm × 86､0","ピエロ　油彩 37､5 × 46､0","あじさい 油彩 41､0 × 51､0","ふたり 油彩 28､5 × 35､5","大和路 (1) 水彩画 50､5 × 41､5","大和路 (2) 水彩画 50､5 × 41､5","大和路 (3) 水彩画 50､5 × 41､5","大和路(4) 水彩画 46､5 × 37､5","大和路(5) 水彩画 37､5 × 46､5","大和路 (6) 水彩画 50､5 × 41､5","大和路 (7) 水彩画 50､5 × 41､5","横浜にて(1) 水彩画 28､0 × 34､0","横浜にて(2) 水彩画 28､0 × 34､0");
						break;
						
					case 7:
						images = Array("IMG_0036.JPG","IMG_0002.JPG","IMG_0007.JPG","IMG_0019.JPG","IMG_0024.JPG","IMG_0031.JPG");
						alts = Array("春爛漫　ー昼神温泉の河原に咲く源平桃ー","誇り　シダレザクラ　ービルの谷間で　in NAGOYAー","しっとりと　枝垂れ梅（天白　農業センター）","桜　揺らぐ（東海市　大池公園）","桜の園（ 駒ヶ根 光前寺 ）","山里の春（ 駒ヶ根 ）");
						break;
						
					case 8:
						images = Array("image2.jpg","image4.jpg","image5.jpg","image6.jpg","image7.jpg","image8.jpg","image10.jpg","image12.jpg","image13.jpg","image14.jpg");
						alts = Array("１　ゆず　４１ｘ　３８．５","２　戌とし　　　２９×３５","３ 春だよ（つくし）　２９×３５","４ トルコキキョウ　　３５×２９","５　ネコヤナギ　　　２４×２９","６ 菜の花　　　　　２９×２４","７　蕪（かぶら）　　　２９ｘ２４","８　しいたけ　　２９×３５","９　朝市のとびうお　２９×３５","１０　タマネギ・バラ・刺身で一献 ２６．５×５１．５");
						break;
						
					case 9:
						images = Array("IMG_0079.JPG","IMG_0071.JPG","IMG_0092.JPG","IMG_0125.JPG","IMG_0098.JPG","IMG_0107.JPG","IMG_0101.JPG","IMG_0100.JPG","IMG_0134.JPG");
						alts = Array("１　ネコ（親子）　\700 (左）・ \500（右）","２　雛人形　\1,300","３ フクロウ　\500","４ 袋(３種）　各　\1,300","５　袋（１種）　\1,300","６ ネコとピエロ　\700 (左）・\800 (右）","７　トンボ　各　\400","８　カメ　各　\500","９　ベア　\1,000");
						break;
						
					case 10:
						images = Array("IMG_0013.JPG","IMG_0007.JPG","IMG_0053.JPG","IMG_0057.JPG","IMG_0060.JPG","IMG_0055.JPG","IMG_0049.JPG","IMG_0005.JPG","IMG_0009.JPG","IMG_0039.JPG","IMG_0029.JPG","IMG_0065.JPG","IMG_0068.JPG");
						alts = Array("１．ベア（ピンク １）\3,500（本体）\500（シート） 売約済","２．ベア（ピンク 2)\3,500（本体）\500（シート）","３．ベア（ブルー）\3,500（本体）\500（シート）","４．ベア（柄）\3,000（本体）\500（シート）売約済","５．ベア（柄・赤）\3,000 売約済","６．ウサギ（ピンク）\3,500（本体）\500（シート）売約済","７．ウサギ（ブルー）\3,500（本体）\500（シート）売約済","８．ウサギ（パープル）\3,500（本体）\500（シート）","９．ウサギ（柄）\3,000（本体）\500（シート）","１０．キーホルダー（ブルー）\400（左）\500（中）\400（右）","１１．キーホルダー（ピンク）\400（左）\500（中）\400（右）","１２．壁掛け（ピンク）\1,000","１３．壁掛け(ブルー）\1,000");
						break;
						
					default:
						break;
				}
				
				for(i=0;i<images.length;i++){
					images[i] = folder + images[i];
				}
				
				ed_js(images,alts);
}