// JavaScript Document
/*var in_menu = "menu1";
var in_mado = "mado1";
function mado_io(id_menu,id_mado){
	if(in_mado==id_mado){
	document.getElementById(id_mado).style.visibility='hidden';
	document.getElementById(id_menu).style.backgroundColor='#eeeeee';
	document.getElementById(id_menu).style.border='1px outset #ffffee';
	in_mado="";
	in_menu="";
	}else{
	if(in_menu!=""){
		document.getElementById(in_mado).style.visibility='hidden';
		document.getElementById(in_menu).style.backgroundColor='#eeeeee';
		document.getElementById(in_menu).style.border='1px outset #ffffee';
		}
	document.getElementById(id_mado).style.visibility='visible';
	document.getElementById(id_menu).style.backgroundColor='#ffffff';
	document.getElementById(id_menu).style.border='1px inset #ffffee';
	in_mado=id_mado;
	in_menu=id_menu;
	}
}

function ed(sel_ed,sel_p) {
	document.getElementById(sel_p).innerHTML = document.getElementById(sel_ed).value;
}*/

function ed_js(images,alts) {
	sinw = window.open();
	sinw.document.open();
	
	var value = "";
	value = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'><html xmlns='http://www.w3.org/1999/xhtml'><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><script type='text/javascript'>";
			
	value += 'photo=new Array();daimei=new Array();var pn=0,dn=0;var hayasa=3000;';
			
	for(i=0;i<images.length;i++){
		value += 'photo[pn++]="'+images[i]+'";daimei[dn++]="'+alts[i]+'";';
	}
			
	value += 'var n=photo.length;p_obj=new Array();for(t=0;t<n;t++){p_obj[t]=new Image();p_obj[t].src=photo[t];}var b=navigator.appName.toUpperCase();var f_no=0,l_no=n-1,i=f_no,tid_sl,hata_sl=false,fe,p_width,f_tid,min=5;function k_t(){if(hata_sl){teisi();hata_sl=false;}else{kaisi();hata_sl=true;};}function kaisi(){clearInterval(tid_sl);tugi();document.getElementById("but_sl").value="停止";tid_sl=setInterval("tugi();",hayasa);}function teisi(){clearInterval(tid_sl);document.getElementById("but_sl").value="開始";}function saisyo(){p_hyouji_mae();i=f_no;p_hyouji_fe();}function mae(){p_hyouji_mae();if(i>0){i--;p_hyouji_fe();}else{i=l_no;p_hyouji_fe();}}function tugi(){p_hyouji_mae();if(i<l_no){i++;p_hyouji_fe();}else{i=f_no;p_hyouji_fe();}}function p_hyouji_mae(){p_width=p_obj[i].width;}function n_hyouji(){document.getElementById("text").innerHTML=daimei[i]+" ： "+(l_no+1)+" 枚中 "+(i+1)+" 枚目";}function p_hyouji_fe(){if(document.getElementById("(C)").href=="http://www.geocities.jp/miyake_kobo/"){clearTimeout(f_tid);fe=100;fe_out();}}function fe_out(){if(fe>0){core_fade("myta",fe);fe-=min*3;f_tid=setTimeout("fe_out();",30);}else{p_hyouji("myimg",i);n_hyouji();clearTimeout(f_tid);core_fade("myta",100);fe=1;fe_in();}}function fe_in(){if(fe<40){core_width("myimg",p_obj[i].width-Math.pow(0.8,fe)*p_obj[i].width);fe++;f_tid=setTimeout("fe_in();",30);}else{clearTimeout(f_tid);core_width("myimg",p_obj[i].width);}}function core_fade(mononoid,suuti){if(window.ActiveXObject){document.getElementById(mononoid).filters["alpha"].opacity=suuti;}else{document.getElementById(mononoid).style.opacity=suuti/100;}}function core_width(mononoid,suuti){document.getElementById(mononoid).style.width=suuti;}function p_hyouji(mono,suu){document.getElementById(mono).src=p_obj[suu].src;}function top(){if(document.getElementById("(C)").firstChild.nodeValue=="Miyake_kobo."){p_hyouji("myimg",i);n_hyouji();}}</script></head><body style="background-color:#000000;margin:0;" onload="top();"><div style="position:absolute;top:0;left:0;width:99%;text-align:right;color:#999999;font-size:8px;">(C) Script by<a id="(C)" href="http://www.geocities.jp/miyake_kobo/" style="color:#999999;">Miyake_kobo.</a></div><center><table id="myta" style="position:absolute;top:10;left:0;width:100%;height:100%;filter:alpha(opacity=100);opacity:1;"><tr><td><center><img id="myimg" galleryimg=no><br><span id="text" style="color:#ffffff;font-size:12px;">Loading now !!</span></center></td></tr></table></center><div style="position:absolute;top:0;left:0;"><input type="button" onclick="saisyo();" value="最初" style="width:50;cursor:pointer;"><input type="button" onclick="mae();" value="前の写真" style="width:70;cursor:pointer;"><input type="button" onclick="tugi();" value="次の写真" style="width:70;cursor:pointer;"><input id="but_sl" type="button" onclick="k_t();" value="開始" style="width:50;cursor:pointer;"></div></body>;</html>';
	
	sinw.document.write(value);
	sinw.document.close();
}

/*
function ed_if(sel_ed) {
	myif.document.open();
	myif.document.write(document.getElementById(sel_ed).value);
	myif.document.close();
}

function ed_win(sel_ed,ed_n,ed_x,ed_y) {
	sinw = window.open("../blank.html",ed_n,"width="+ed_y+",height="+ed_x);
	sinw.document.open();
	sinw.document.write(document.getElementById(sel_ed).value);
	sinw.document.close();
}

function resetf(){
	location.href=location.href;
}
//--------------------------------------------------
var source_hata=false;

function source_hyouji(){
	if(source_hata){
		document.getElementById("source_but").value="ソースを表示";
		document.getElementById("source_area").style.height=10;
		document.getElementById("source_area").style.visibility="hidden";
		source_hata=false;
	}else{
		document.getElementById("source_but").value="ソースを消去";
		document.getElementById("source_area").style.height=source_height;
		document.getElementById("source_area").style.visibility="visible";
		source_hata=true;
	}
}

function source_wop() {
	var source_data=document.getElementById("source_area").value;
	var source_data_html="<html><body><center>"+source_data+"</center>";
	sinw = window.open();
	sinw.document.open();
	sinw.document.write(source_data_html);
	sinw.document.close();
}
*/