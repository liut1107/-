var instagram_business_id = '17841405920104198'; //ここにInstagramビジネスアカウントIDを入力してください。 
var access_token = 'EAAifXaWs3WoBABOSSjU2miC2y9gRmm9I4JV2C7JnH3H2IwGqUn2LKQg0wRVappZBRBNkKC1Sgndaldytzc3f7haZAZAXTbTbX3tdawDVASZAqTsyZCnlyecFpCTjoZCVQD1ZBRZCdT18cYd74StUxm7eETWIV4oaOtQWZBL5J8670yFCf1y8l2w95bpef73j8dmgZD'; //ここに3段階目のアクセストークンを入力してください。

var target_user = 'queensspa23'; //ここに取得したいInstagramビジネスアカウントのユーザー名を入力してください。（例えばArrownのInstagramであればURLがhttps://www.instagram.com/arrown_blog/なので「arrown_blog」がユーザー名になります。このアカウント全然更新してないけど。。。）

//自分が所有するアカウント以外のInstagramビジネスアカウントが投稿している写真も取得したい場合は以下
var query = 'business_discovery.username('+target_user+'){id,followers_count,media_count,ig_id,media{caption,media_url,permalink,media_type,like_count,comments_count,timestamp,id}}';

//自分のアカウントの画像が取得できればOKな場合は$queryを以下のようにしてください。

//$query = 'name,media{caption,like_count,media_url,permalink,timestamp,username}&access_token='.$access_token;

var instagram_api_url = 'https://graph.facebook.com/v5.0/';
var target_url = instagram_api_url+instagram_business_id+"?fields="+query+"&access_token="+access_token;

$.ajax({
  type: 'GET',
  url: target_url,
  dataType: 'json',
  success: function(instagram_data) {
    var gallery_data = instagram_data['business_discovery']['media']['data'];
    var photos = '';
    for(var i in gallery_data){
		var curData = gallery_data[i];
		//photos += '<li class="gallery-item"><a href="'+ curData.permalink +'" target="_blank"><img src="' + curData.media_url + '"></a></li>';
		photos += '<li style="background-image: url('+ curData.media_url +')"><a href="'+ curData.permalink +'" target="_blank"></a></li>';
	} 
	$('#instafeed').html(photos);
    }, error:function(e) {
    	console.log(e);
    }
});