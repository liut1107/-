﻿if(((navigator.userAgent.indexOf('iPhone') > 0) || (navigator.userAgent.indexOf('Android') > 0) && (navigator.userAgent.indexOf('Mobile') > 0) && (navigator.userAgent.indexOf('SC-01C') == -1))){
document.write('<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">');
}                                         

//page-scroller
$(function(){
	$('a[href*=\\#]:not([href=\\#])').click(function() {
	if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			var $target = $(this.hash);
			$target = $target.length && $target || $('[name=' + this.hash.slice(1) +']');
			if ($target.length) {
				if($(this).parents('.menuBox').length){
					setTimeout(function(){
						var targetOffset = $target.offset().top - $('#gHeader').innerHeight();
						$('html,body').animate({scrollTop: targetOffset}, 1000);
					},100);
				}else{
					var targetOffset = $target.offset().top - $('#gHeader').innerHeight();
					$('html,body').animate({scrollTop: targetOffset}, 1000);
				}
				return false;
			}
		}
	});
	
	
	var state = false;
	var scrollpos;
	$('.menu').on('click', function(){
		if(state == false) {
			scrollpos = $(window).scrollTop(); 
			$('body').addClass('fixed').css({'top': -scrollpos}); 
			$('.menu').addClass('active');
			$('.menuBox').stop().slideToggle();
			state = true;
		} else {
			$('body').removeClass('fixed').css({'top': 0});
			window.scrollTo( 0 , scrollpos ); 
			$('.menu').removeClass('active');
			$('.menuBox').stop().slideToggle();
			state = false;
		}
		return false;
	});
	
	$('.iconSpan').click(function(){
		if($(this).text() == "+"){
			$(this).text('—');
		}else {
			$(this).text('+');
		}
		
		$(this).toggleClass('on');//加class来写改变icon
		$('.menuUl').stop().slideToggle();
		
		//return false; iconSpan不是<a>，所以不用加return false;
	});
	
	
	$('.menuBox .menuList a').click(function(){
		$('body').removeClass('fixed').css({'top': 0});
			window.scrollTo( 0 , scrollpos ); 
		$('.menuBox').stop().slideToggle();
		$('.menu').removeClass('active');
		state = false;
	});
	
	
});

$(window).on('load',function(){
	var localLink = window.location+'';
	if(localLink.indexOf("#") != -1){
		localLink = localLink.slice(localLink.indexOf("#")+1);
		$('html,body').animate({scrollTop: $('#'+localLink).offset().top - $('#gHeader').innerHeight()}, 500);
	}
});