
	var spW = 768,    // SP max width, not contain
    isSp,         // Is SP or not
    winW,         // Window width
    winH,         // Window height
    winST,        // Window scrollTop
    isChange;     // Is change to PC/SP

var ready, visited;

$(function(){
  visited = sessionStorage.getItem('visited');
  if (visited) $('.firstView').hide();

  $(window).load(function(){
    pageReady();
  });

  setTimeout(function(){
    pageReady();
  }, 1500);

  $(window).resize(function(){
    setBanner();
    setSvgHeight();
  }).trigger('resize');
});

function pageReady() {
  if (ready) return;
  ready = true;

  $('body').addClass('hideCover');
  setTimeout(function(){
    $('body').addClass('loaded');

    $(window).scroll(function(){
      setKabList();
    }).trigger('scroll');

    if (visited) {
      initFv();
    } else {
      TweenMax.to($('.firstView'), 0.7, {
        ease:Power0.easeNone,
        delay: 2.2,
        opacity: 0,
        onComplete: initFv
      });
    }

    sessionStorage.setItem('visited', true);
  }, isSp ? 0 : 800);
}

function initFv() {
  $('.firstView').hide();
  initBanner();
  TweenMax.to($('#bannerSlider'), .5, {opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.rightWord .rightWord01'), 0, {delay:1.4,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.rightWord .rightWord02'), 0, {delay:1.6,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.rightWord .rightWord03'), 0, {delay:1.8,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.rightWord .rightWord04'), 0, {delay:2.0,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.leftWord .leftWord01'), 0, {delay:2.2,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.leftWord .leftWord02'), 0, {delay:2.4,opacity:1,ease:Power0.easeNone});
  TweenMax.to($('.leftWord .leftWord03'), 0, {delay:2.6,opacity:1,ease:Power0.easeNone});
  // TweenMax.to($('.internship'), 0, {delay:2.8,opacity:1,ease:Power0.easeNone});
}

function initBanner() {
  var duration = 5;
  var speed = 1.9;
  var slider = $('#bannerSlider');
  var curIndex = 0;
  var sliderItem = slider.find('li');

  sliderItem.eq(curIndex).addClass('on').find('.skew').css('clip', 'inherit');
  TweenMax.set(sliderItem.eq(curIndex),{scale:1,x:0,y:0});
  TweenMax.to(sliderItem.eq(curIndex),duration+speed,{scale:1.1,ease:Power0.easeNone,force3D:false});

  TweenMax.delayedCall(duration, next);

  function next() {
    curIndex = (curIndex + 1) % sliderItem.length;
    var obj = sliderItem.eq(curIndex);
    obj.addClass('on').siblings().removeClass('on');
    animate(obj);

    var skew = obj.find('.skew');
    TweenMax.set(skew,{clip:'rect(0px,0px,'+winH+'px,0px)'});
    TweenMax.to(skew,speed,{
      clip:'rect(0px,'+(isSp?1.8:1.5)*winW+'px,'+winH+'px,0px)',
      ease:Power4.easeInOut,
      onComplete: function () {
        skew.css({clip: 'inherit'});
      }
    });
    TweenMax.set(skew,{clip:'rect(0px,0px,'+winH+'px,0px)',delay:duration+speed});

    TweenMax.delayedCall(duration, next);
  }

  function animate(target) {
    if (curIndex == 0) {
      TweenMax.set(target,{scale:1,x:0,y:0})
      TweenMax.to(target,duration+speed,{scale:1.1,ease:Power0.easeNone,force3D:false});
    } else if (curIndex == 1) {
      TweenMax.set(target,{scale:1.1,x:winW/20,y:0})
      TweenMax.to(target,duration+speed,{x:0,ease:Power0.easeNone,force3D:false});
    } else if (curIndex == 2) {
      TweenMax.set(target,{scale:1.1,x:-winW/20,y:winH/20})
      TweenMax.to(target,duration+speed,{x:0,ease:Power0.easeNone,force3D:false});
    } else if (curIndex == 3) {
      TweenMax.set(target,{scale:1.1,x:0,y:winH/20})
      TweenMax.to(target,duration+speed,{y:0,ease:Power0.easeNone,force3D:false});
    } else if (curIndex == 4) {
      TweenMax.set(target,{scale:1.1,x:0,y:-winH/20})
      TweenMax.to(target,duration+speed,{y:0,ease:Power0.easeNone,force3D:false});
    }
  }
}

function setBanner() {
  if ($('#banner').length) {
    $('#banner').height(winH);

    var w = isSp ? winW : (winW > 1100 ? winW : 1100);
    $('#bannerSlider .pic').width(w);
  }
}

function setSvgHeight() {
  var s1 = $(".leftWord").innerHeight();
  $(".leftWord svg").height(s1)
  $(".leftWord svg").width(s1*0.278)
  $(".leftWord").width(s1*0.278)

  var s2 = $(".rightWord").innerHeight();
  $(".rightWord svg").height(s2)
  $(".rightWord svg").width(s2*0.212)
  $(".rightWord").width(s2*0.212)
}

function setKabList() {
  $('.kabList li').each(function(i){
    var _this = $(this);
    if (_this.data('visible')) return;

    if (winST >= _this.offset().top - winH + 200) {
      _this.data('visible', true);
      setTimeout(function(){_this.addClass('visible')}, 500);
      var target = _this.find('.clip');
      var text = _this.find('.kabBox');
      TweenMax.set(target, {clip: 'rect(0px, 0px, ' + _this.outerHeight() + 'px, 0px)'});
      TweenMax.to(target, 1, {
        clip: 'rect(0px, ' + _this.outerWidth() + 'px, ' + _this.outerHeight() + 'px, 0px)',
        ease: Power4.easeInOut,
        onComplete: function () {
          target.css({clip: 'initial'});
        }
      });
      TweenMax.to(text, 1, {
        delay: .2,
        opacity: 1,
        ease: Power4.easeInOut
      });
    }
  });
}